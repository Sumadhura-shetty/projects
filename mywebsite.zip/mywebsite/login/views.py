
from .models import Account
from typing import cast
from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
#from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, UserManager


# Create your views here.
def home(request):
    return render(request,'index.html')

def register(request):
    if request.method =='POST':
         username=request.POST['username']
         phone=request.POST['phone']
         email=request.POST['email']
         password=request.POST['password']
         user_obj =Account.objects.create(username=username, phone=phone, email=email, password=password)
         user_obj.save()
    #request.session['username'] = user.username
         messages.success(request, 'user name created')   
         print(' user created') 
    return redirect('/')

def log_in(request):
     if request.method =='POST':
          username=request.POST['username']
          password=request.POST['password']

          if(Account.objects.filter(username=username).exists()):
               if(Account.objects.filter(password=password).exists()):
                    messages.success(request, 'you are logged')
                    print('you are logged')
                    return render(request , 'home.html') 
               else:
                    messages.error(request, 'wrong password')
                    print('wrong password')
                    return redirect('/') 
          else:
                messages.error(request, 'User Name Not Exist')
          
          user_obj =Account.objects.filter(username=username,password=password)
          if not user_obj:
               messages.success(request, 'username not found')
               print('username not found')
               return redirect('/') 
     return render(request,'index.html')
         
